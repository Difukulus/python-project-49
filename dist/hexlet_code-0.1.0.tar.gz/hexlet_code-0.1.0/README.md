
### Hexlet tests and linter status:
[![Actions Status](https://github.com/Difukulus/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Difukulus/python-project-49/actions)

"!https://api.codeclimate.com/v1/badges/1be6042500fe3a537f27/maintainability!":https://codeclimate.com/github/Difukulus/python-project-49/maintainability

brain-even:
https://asciinema.org/a/iSzRldwFwlXcGgNEgmiJZgsUp

brain-calk:
https://asciinema.org/a/AK5ltbhWLYxnaGY61XPVcYZsg

brain-gcd:
https://asciinema.org/a/WS9PEl8rfnTl9cm3ORxzovyuE
