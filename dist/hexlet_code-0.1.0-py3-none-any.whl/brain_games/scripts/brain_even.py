from brain_games.scripts.brain_games import main as brain_games_main
import random


def main():
    name = brain_games_main()
    cnt = 0
    print('Answer "yes" if the number is even, otherwise answer "no".')
    while cnt < 3:
        random_number = random.randint(1, 100)
        print(f'Question: {random_number}')
        answer = input("Your answer: ")
        if (random_number % 2 == 0 and answer == "yes") or (random_number % 2 != 0 and answer == "no"):
            print("Correct!")
        elif random_number % 2 == 0 and answer != "yes":
            print(f"'{answer}' is wrong answer ;(. Correct answer was 'yes'.\nLet's try again, {name}!")
            break
        elif random_number % 2 != 0 and answer != "no":
            print(f"'{answer}' is wrong answer ;(. Correct answer was 'no'.\nLet's try again, {name}!")
            break
        cnt += 1
        if cnt == 3:
            print(f'Congratulations, {name}!')


if __name__ == '__main__':
    main()
